<?php
// التحقق من تسجيل الدخول في كل صفحة إدارية
if (!isLoggedIn()) {
    header("Location: ../login.php");
    exit();
}
?>
<!-- شريط التنقل العلوي -->
<nav class="navbar navbar-dark bg-dark fixed-top shadow">
    <div class="container-fluid">
        <!-- زر فتح القائمة الجانبية -->
        <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#sidebar">
            <span class="navbar-toggler-icon"></span>
        </button>
        
        <!-- عنوان الصفحة -->
        <div class="navbar-brand mx-auto">
            <i class="bi bi-speedometer2 me-2"></i>
            <span class="d-none d-md-inline">لوحة التحكم - <?php echo SITE_NAME; ?></span>
        </div>
        
        <!-- القائمة العلوية اليمنى -->
        <div class="d-flex align-items-center">
            <!-- إشعارات -->
            <div class="dropdown me-3">
                <a class="text-white text-decoration-none position-relative" href="#" data-bs-toggle="dropdown">
                    <i class="bi bi-bell fs-5"></i>
                    <?php
                    // عد الرسائل الجديدة
                    $stmt = $pdo->query("SELECT COUNT(*) FROM contact_messages WHERE status = 'new'");
                    $new_messages = $stmt->fetchColumn();
                    
                    // عد طلبات الانضمام المعلقة
                    $stmt = $pdo->query("SELECT COUNT(*) FROM join_requests WHERE status = 'pending'");
                    $pending_requests = $stmt->fetchColumn();
                    
                    $total_notifications = $new_messages + $pending_requests;
                    ?>
                    <?php if($total_notifications > 0): ?>
                    <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                        <?php echo $total_notifications; ?>
                    </span>
                    <?php endif; ?>
                </a>
                <ul class="dropdown-menu dropdown-menu-end">
                    <li><h6 class="dropdown-header">الإشعارات</h6></li>
                    <?php if($new_messages > 0): ?>
                    <li>
                        <a class="dropdown-item" href="messages.php">
                            <i class="bi bi-envelope text-primary"></i>
                            <?php echo $new_messages; ?> رسالة جديدة
                        </a>
                    </li>
                    <?php endif; ?>
                    <?php if($pending_requests > 0): ?>
                    <li>
                        <a class="dropdown-item" href="members/join-requests.php">
                            <i class="bi bi-person-plus text-success"></i>
                            <?php echo $pending_requests; ?> طلب انضمام
                        </a>
                    </li>
                    <?php endif; ?>
                    <?php if($total_notifications == 0): ?>
                    <li><a class="dropdown-item text-muted">لا توجد إشعارات جديدة</a></li>
                    <?php endif; ?>
                    <li><hr class="dropdown-divider"></li>
                    <li><a class="dropdown-item" href="messages.php">عرض جميع الإشعارات</a></li>
                </ul>
            </div>
            
            <!-- حساب المستخدم -->
            <div class="dropdown">
                <a href="#" class="text-white text-decoration-none dropdown-toggle d-flex align-items-center" data-bs-toggle="dropdown">
                    <i class="bi bi-person-circle me-2"></i>
                    <span class="d-none d-md-inline"><?php echo $_SESSION['user_name']; ?></span>
                </a>
                <ul class="dropdown-menu dropdown-menu-end">
                    <li>
                        <a class="dropdown-item" href="../index.php" target="_blank">
                            <i class="bi bi-house me-2"></i> الموقع الرئيسي
                        </a>
                    </li>
                    <li>
                        <a class="dropdown-item" href="profile.php">
                            <i class="bi bi-person me-2"></i> الملف الشخصي
                        </a>
                    </li>
                    <li>
                        <a class="dropdown-item" href="settings.php">
                            <i class="bi bi-gear me-2"></i> الإعدادات
                        </a>
                    </li>
                    <li><hr class="dropdown-divider"></li>
                    <li>
                        <a class="dropdown-item text-danger" href="../logout.php">
                            <i class="bi bi-box-arrow-left me-2"></i> تسجيل الخروج
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</nav>

<!-- شريط الحالة -->
<div class="status-bar bg-light border-bottom py-2">
    <div class="container-fluid">
        <div class="row align-items-center">
            <div class="col-md-6">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb mb-0">
                        <li class="breadcrumb-item">
                            <a href="dashboard.php" class="text-decoration-none">
                                <i class="bi bi-house"></i> الرئيسية
                            </a>
                        </li>
                        <?php if(isset($pageTitle) && $pageTitle != 'لوحة التحكم'): ?>
                        <li class="breadcrumb-item active"><?php echo $pageTitle; ?></li>
                        <?php endif; ?>
                    </ol>
                </nav>
            </div>
            <div class="col-md-6 text-end">
                <small class="text-muted">
                    <i class="bi bi-clock"></i> 
                    <?php echo date('Y-m-d H:i:s'); ?>
                    <?php if(isAdmin()): ?>
                    | <i class="bi bi-shield-check text-success"></i> مسؤول
                    <?php else: ?>
                    | <i class="bi bi-person"></i> <?php echo $_SESSION['user_role'] === 'editor' ? 'محرر' : 'مشرف'; ?>
                    <?php endif; ?>
                </small>
            </div>
        </div>
    </div>
</div>

<!-- تأكد من تحميل المكتبات بالترتيب الصحيح -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<!-- أو إذا كنت تستخدم ملفات محلية -->
<script src="../js/bootstrap.bundle.min.js"></script>
<script src="../js/chart.js"></script>