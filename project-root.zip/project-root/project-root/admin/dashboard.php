<?php
require_once '../config.php';
require_once '../db.php';
require_once '../functions.php';

// التحقق من تسجيل الدخول
if (!isLoggedIn()) {
    header("Location: ../login.php");
    exit();
};

$pageTitle = "لوحة التحكم";
include 'includes/header.php';
// الـ navbar يتم تضمينه تلقائياً من خلال header.php
?>

<div class="container-fluid mt-5">
    <div class="row">
        <?php include 'includes/sidebar.php'; ?>
        
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4" style="margin-top: 80px;">
            <!-- محتوى لوحة التحكم يبدأ هنا -->
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">النظرة العامة</h1>
                <div class="btn-toolbar mb-2 mb-md-0">
                    <div class="btn-group me-2">
                        <span class="btn btn-sm btn-outline-secondary"><?php echo date('Y-m-d'); ?></span>
                    </div>
                </div>
            </div>

            <!-- باقي محتوى الـ dashboard -->
            <!-- ... -->
            
        </main>
    </div>
</div>

<?php include 'includes/footer.php'; ?>